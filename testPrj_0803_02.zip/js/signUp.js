window.addEventListener("load", function () {

    let inputDiv = document.querySelector("#input-block");
    const btnDiv = document.querySelector(".button-block");

    let signId = inputDiv.querySelector(".sign-id");
    let signPw = inputDiv.querySelector(".sign-pw");
    let signChkPw = inputDiv.querySelector(".sign-ch-pw");
    let signNm = inputDiv.querySelector(".sign-nm");

    const cnclBtn = btnDiv.querySelector("input:first-child");
    const signBtn = btnDiv.querySelector("input:first-child+input");

    const MEMBER = "member";
    let jsonMember = new Array();
    let arrLen = 0;
    let tryCnt;

    function validate(){
        if (signId.value == null || signId.value == "" || signId.value == undefined) {
            alert("ID를 입력해 주세요.");
            signId.focus();
            return false;
        } else if (signPw.value == null || signPw.value == "" || signPw.value == undefined) {
            alert("비밀번호를 입력해 주세요.");
            signPw.focus();
            return false;
        } else if (signChkPw.value == null || signChkPw.value == "" || signChkPw.value == undefined) {
            alert("비밀번호를 한번 더 입력해 주세요.");
            signChkPw.focus();
            return false;
        } else if (signNm.value == null || signNm.value == "" || signNm.value == undefined) {
            alert("이름을 입력해 주세요.");
            signNm.focus();
            return false;
        } else if (signPw.value !== signChkPw.value) {
            alert("입력하신 두 비밀번호가 일치하지 않습니다.");
            signChkPw.focus();
            return false;
        }
    };

    function insertMember(){
        const memberObj = { "UNUM": arrLen + 1, "ID": signId.value, "PW": signPw.value, "NM": signNm.value };

        console.log("insertMember() obj : "+"UNUM:"+ (arrLen + 1)+ ",ID:"+ signId.value +",PW:"+ signPw.value+",NM :"+ signNm.value);
        if(jsonMember == null)
        {
            console.log("jsonMember == null");
            let member = new Array();
            member.push(memberObj);
            jsonMember = member;
        } else {
            console.log("jsonMember != null");
            jsonMember.push(memberObj);
        }

        const arrStr = JSON.stringify(jsonMember);

        console.log("1-2 member : " + jsonMember.length);
        console.log("1-2 member Str : " + arrStr);

        localStorage.setItem(MEMBER, arrStr);

        alert(`${signId.value}님. 회원가입을 축하드립니다.
        로그인 화면으로 이동합니다.`);

        location.replace("login.html");
    };

    signBtn.onclick = function () {
        const lsMember = localStorage.getItem(MEMBER);
        jsonMember = JSON.parse(lsMember);

        console.dir("localStorage.getItem(MEMBER) : " + lsMember);
        console.log(jsonMember);

        //PW, chkPW 일치 확인
        let tOrF = validate();
        console.log(tOrF);

        if(tOrF == false)
        {
            return;
        }

        //1. currentUser의 길이 확인
        if (lsMember !== null) {
            arrLen = jsonMember.length;
        } else {

            arrLen = 0;
        }

        console.log("1. currentUser의 길이 확인 : " + arrLen);


        //1-2. 스토리지의 id와 비밀번호를 담을 변수 선언
        let lsData;

        console.log("1-2 arrLen : " + arrLen);
        if (arrLen == 0) {
           
            console.log(jsonMember);
            insertMember();

        } else {

            console.log(arrLen);
            //2. 길이만큼 반복
            for (let i = 0; i < arrLen; i++) {
                //3. 각 회차별 id 비교. 일치 여부 확인
                lsData = jsonMember[i];

                console.log(lsData);

                if (signId.value == lsData.ID) {
                    //3-1 일치하는 id가 있으면 중지.
                    alert("이미 가입된 ID입니다.");
                    return;
                }
            } //for end

            //5-1.ls에서 가져온 데이터에 붙여넣기
            insertMember();

        } //if(arrLen == 0) end
    }; //onclick end

    cnclBtn.onclick = function () {
        //1. 입력 전 취소버튼을 누른 경우
        if (signId.value == null &&
            signPw.value == null &&
            signChkPw.value == null &&
            signNm.value == null) {
            //1-1 로그인 화면으로 돌아간다.
            location.replace("login.html");
        } else
        //2. 입력 중 취소버튼을 누른 경우
        {
            //2-1 입력을 취소할 것인지 확인한다.
            const tOf = confirm("입력한 내용을 취소하시겠습니까?")
            console.log(tOf);

            //2-2 입력을 취소할 경우
            if (tOf == true) {
                console.log("2-2 t or f? : " + tOf);
                //2-3 로그인 화면으로 돌아간다.
                location.replace("login.html");
            }
            //2-4 입력을 취소하지 않을 경우 아무 일도 일어나지 않는다.
            console.log("2-4 t or f? : " + tOf);
        }
    };
});