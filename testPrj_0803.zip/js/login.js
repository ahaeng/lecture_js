window.addEventListener("load", function () {
    const idDiv = document.querySelector("#idDiv");

    const idInput = idDiv.querySelector("input:nth-child(1)");
    const pwInput = idDiv.querySelector("input:nth-child(2)");
    const btn = idDiv.querySelector("input[value='submit']");
    const signUp = idDiv.querySelector("a");

    const USER_LS = "member";

    btn.addEventListener("click",
        function () {

            const lsMember = localStorage.getItem(USER_LS);

            //0. USER_LS가 null 일 경우 배열 입력

            //1. currentUser의 길이 확인
            const arrLen = currentUser.length;

            //2. 길이만큼 반복
            //3. 각 회차별 id 비교
            //4. id 일치할 경우 pw 비교
            //5. pw 틀릴 경우 회차 보관 및 try 숫자 보관



            if (txtInput.value == currentUser) {

            } else {

            }

        }
    );

});