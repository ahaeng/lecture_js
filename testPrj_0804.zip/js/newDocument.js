window.addEventListener("load", function () {
    const main = document.querySelector("main");

    const title = main.querySelector(".title");
    const content = main.querySelector("#content");
    let regDate = main.querySelector(".reg-date");
    const hit = main.querySelector(".hit");

    const submitBtn = main.querySelector(".submit");
    const cnclBtn = main.querySelector(".cncl");

    let jsonParse = new Array();

    const DOC_CONTENT = "DOC_CONTENT",
        UNUM = "UNUM",
        TITLE = "TITLE",
        CONTENT = "CONTENT",
        REGDATE = "REGDATE",
        HIT = "HIT";

    function getRegDate() {
        const date = new Date();
        const years = `${date.getFullYear() < 10 ? `0${date.getFullYear()}` : date.getFullYear()}`;
        const months = `${date.getMonth() < 10 ? `0${date.getMonth()}` : date.getMonth()}`;
        const days = `${date.getDate() < 10 ? `0${date.getDate()}` : date.getDate()}`;
        regDate.value = years + "-" + months + "-" + days;
    };

    getRegDate();

    let arrLen = 0;

    content.value = "";

    submitBtn.addEventListener("click", function () {
        // console.log(content.value);
        const lsContent = localStorage.getItem(DOC_CONTENT);

        jsonParse = JSON.parse(lsContent);

        console.log(lsContent);
        if (lsContent != null) {
            console.log(jsonParse.length);
            arrLen = jsonParse.length;
        } else {
            arrLen = 0;
        }

        console.log(typeof (content.value));

        const contentObj = {
            UNUM: arrLen + 1,
            TITLE: title.value,
            CONTENT: content.value,
            REGDATE: regDate.value,
            HIT: hit.value
        };

        if (jsonParse == null) {
            console.log("jsonParse == null");
            let member = new Array();
            member.push(contentObj);
            jsonParse = member;
        } else {
            console.log("jsonParse != null");
            jsonParse.push(contentObj);
        }

        console.log(jsonParse.length);
        let jsonContent = JSON.stringify(jsonParse);

        console.log(jsonContent);

        localStorage.setItem(DOC_CONTENT, jsonContent);

        location.replace("notice.html");

    });

    cnclBtn.onclick = function () {
        //1. 입력 전 취소버튼을 누른 경우
        if (title.value == null &&
            content.value == null) {
            //1-1 메인 화면으로 돌아간다.
            location.replace("notice.html");
        } else
        //2. 입력 중 취소버튼을 누른 경우
        {
            //2-1 입력을 취소할 것인지 확인한다.
            const tOf = confirm("입력한 내용을 취소하시겠습니까?")
            console.log(tOf);

            //2-2 입력을 취소할 경우
            if (tOf == true) {
                console.log("2-2 t or f? : " + tOf);
                //2-3 로그인 화면으로 돌아간다.
                location.replace("notice.html");
            }
            //2-4 입력을 취소하지 않을 경우 아무 일도 일어나지 않는다.
            console.log("2-4 t or f? : " + tOf);
        }
    };


});