window.addEventListener("load", function () {
    const main = document.querySelector("main");

    // buttons -----------------------------------------
    const newBtn = main.querySelector(".new-notice-btn");
    const serchBtn = main.querySelector(".serch-btn");

    // inputs ------------------------------------------
    const serchIndex = main.querySelector(".serch-index");

    // table -------------------------------------------
    const table = main.querySelector("table");
    const template1 = main.querySelector(".tmpl1");
    const template2 = main.querySelector(".tmpl1");
    const tbody = table.querySelector("tbody");

    // constant ----------------------------------------
    const DOC_CONTENT = "DOC_CONTENT",
        UNUM = "UNUM",
        TITLE = "TITLE",
        CONTENT = "CONTENT",
        REGDATE = "REGDATE",
        HIT = "HIT";

    // variable ----------------------------------------
    let jsonContent = new Array();

    let arrLen = 0;

    // functions ---------------------------------------
    function listLoad() {
        //1. 리스트 데이터 로딩
        const lsContent = localStorage.getItem(DOC_CONTENT);

        jsonContent = JSON.parse(lsContent);

        if (lsContent != null) {
            arrLen = jsonContent.length;
        } else {
            arrLen = 0;
        }


        console.log("arrLen : " + arrLen);
        if (arrLen == 0) {
            let cloneNode = document.importNode(template2.content, true);

            let tds = cloneNode.querySelectorAll("td")
            console.log("template2 : " + cloneNode);

            tds[0].textContent = "게시글 없음";
            tbody.append(cloneNode);
        } else {
            let cloneNode = document.importNode(template1.content, true);

            let tds = cloneNode.querySelectorAll("td")
            console.log("template1 : " + tds[0]);

            for (let i = 0; i < arrLen; i++) {
                tds[0].textContent = jsonContent[i].UNUM;
                tds[1].textContent = jsonContent[i].TITLE;
                tds[2].textContent = jsonContent[i].REGDATE;
                tds[3].textContent = jsonContent[i].HIT;

                tbody.append(cloneNode);
            }
        }

    };

    listLoad();

    newBtn.onclick = function () {
        location.replace("new-document.html");
    };

});