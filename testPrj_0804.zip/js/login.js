window.addEventListener("load", function () {
    const idDiv = document.querySelector("#id-div");

    const idInput = idDiv.querySelector(".id-input");
    const pwInput = idDiv.querySelector(".pw-input");
    const btn = idDiv.querySelector("input[value='submit']");
    const signUp = idDiv.querySelector("a");

    const USER_LS = "member";

    let pwCnt = 0;

    btn.addEventListener("click",
        function () {

            //PW, chkPW 입력 확인
            let tOrF = validate();
            console.log(tOrF);

            if(tOrF == false)
            {
                return;
            }

            console.log("ID : "+idInput.value);
            const lsMember = localStorage.getItem(USER_LS);
            
            //0. USER_LS가 null 일 경우 배열 입력
            if(lsMember == null)
            {
                location.replace("signup.html");
            }

            //로컬스토리지의 데이터를 배열로 변환
            let member = JSON.parse(lsMember);

            //1. currentUser의 길이 확인
            const arrLen = member.length;

            //2. 길이만큼 반복
            for(let i = 0;i<arrLen;i++)
            {
                console.log("위치 확인 : a");
                //3. 각 회차별 id 비교
                if(idInput.value == member[i].ID)
                {
                    //4-1. id 일치할 경우 pw 비교. 일치하면 메인으로
                    if(pwInput.value == member[i].PW)
                    {
                        alert(`환영합니다. ${member[i].NM}님!`)
                        location.replace("index.html");
                    }
                    //4-2. id 일치할 경우 pw 비교. 불일치하면 다음 탐색
                    else 
                    {
                        if(pwCnt < 5)
                        {
                            console.log("i 확인 : "+i);
                            alert(`비밀번호가 ${pwCnt+1}회 틀렸습니다.
                            다시 확인해 주세요.`);

                            pwInput.value = "";
                            pwInput.focus();

                            console.log(pwCnt);
                            pwCnt++;
                        } else
                        {
                            alert("비밀번호를 5회 틀렸습니다. 관리자에게 문의하세요.");
                            
                            idInput.readonly = "true";
                            return;

                        }
                    }
                }
            }
            
            function validate(){
                if (idInput.value == null || idInput.value == "" || idInput.value == undefined) {
                    alert("ID를 입력해 주세요.");
                    idInput.focus();
                    return false;
                } else if (pwInput.value == null || pwInput.value == "" || pwInput.value == undefined) {
                    alert("비밀번호를 입력해 주세요.");
                    pwInput.focus();
                    return false;
                }
            };
        }
        

    );

});